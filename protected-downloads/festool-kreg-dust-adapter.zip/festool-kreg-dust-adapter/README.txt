Festool D27 hose to Kreg K5 dust adapter
Jesper Makes, jespermakes.com

A push-fit adapter between a Festool 27 mm extractor hose and the dust port on a Kreg K5 / K5MS
pocket hole jig. Designed and tested in my workshop with a Festool D27 hose and a Kreg K5.

FILES
  festool-d27-to-kreg-k5-adapter.stl         the adapter with the Jesper Makes logo raised on the side
  festool-d27-to-kreg-k5-adapter-plain.step  the plain body (no logo) as a STEP file, for your own changes

HOW IT FITS
  Wide end:   the Festool D27 hose end pushes IN (35 mm socket, slightly tapered so it grips as it seats)
  Narrow end: pushes INTO the Kreg K5 dust port (31 mm spigot, slightly tapered)
  Height 70 mm, outside diameter 39 mm, 2 mm walls.

PRINT SETTINGS (what I used)
  Material:     PETG (PLA works too, PETG takes knocks better)
  Orientation:  standing up, narrow end on the bed, exactly as the file is placed
  Supports:     none needed, every slope is 45 degrees or steeper
  Layer height: 0.2 mm, 2 walls, 15 % infill
  Time:         about 1 h 20 min on a Bambu Lab H2D, about 17 g

IF IT IS TOO TIGHT OR TOO LOOSE
  Hoses and jigs vary a little. Scale the model 1 to 2 % in X and Y (not Z) to loosen the
  wide end, or down to tighten it, or open the STEP file and change it.

For personal use. Please do not sell the files or prints of them.
Questions: hello@jespermakes.com
